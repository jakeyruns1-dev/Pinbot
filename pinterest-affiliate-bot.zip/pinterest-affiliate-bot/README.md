# Pinterest Affiliate Auto-Poster

Posts your Amazon affiliate products to Pinterest on a schedule, automatically,
using GitHub Actions (free) as the "always-on" runner — nothing needs to stay
running on your own computer.

This version works entirely from a CSV you fill in by hand, since Amazon
Product Advertising API access isn't approved yet. When it is approved later,
only `products.csv` needs to change to a script pull — the posting logic stays
the same.

**v2 update:** the pipeline is now built directly around the affiliate guide's
SEO, image, and compliance rules (see "What's optimized" below) rather than a
generic title/photo template.

## How it works

1. You list products in `products.csv` — including SEO fields (primary
   keyword, secondary keywords, who it's for, the problem it solves) instead
   of just a name and a link.
2. On a schedule (default: 3x/day), GitHub runs `generate_and_post.py`, which:
   - Picks the next eligible product (skipping anything posted in the last
     14 days — see Freshness below)
   - Generates a keyword-optimized title, description, and alt text (`seo.py`)
   - Generates a pin image with a curiosity-gap overlay hook + CTA strip
     (`image_gen.py`), refusing to run if the image URL is Amazon-hosted
   - Posts it to Pinterest via the API with your affiliate link and an
     automatic FTC/Amazon disclosure
   - Logs the post in `posted_log.json` with a timestamp and which
     title/image variant was used
3. Once eligible products run out, add more rows and it keeps going.

## What's optimized (and why)

Every one of these maps to a specific rule from the guide:

| Guide rule | Where it's implemented |
|---|---|
| Front-load the primary keyword in the first 3-4 words of the title | `seo.generate_title()` |
| Natural language, not keyword-stuffed descriptions | `seo.generate_description()` — primary keyword in sentence 1, 2-3 secondary keywords woven in, no bullet/emoji lists |
| Alt text is "the most underused SEO element" | `seo.generate_alt_text()` — populated on every pin |
| Don't show the full product/result — create curiosity | `image_gen.build_pin_image()` uses a hook like "Why this ___ keeps selling out" instead of describing the product outright |
| Add a direct CTA, not "link in bio" | Red CTA strip on every pin image ("Shop this find below", etc.) |
| Bold, high-contrast, large text for mobile | Enforced font sizes + solid-color banners in `image_gen.py` |
| Never use Amazon product images as your pin image | `image_gen.assert_not_amazon_image()` — hard refusal, not a warning, if the image URL is an Amazon media domain |
| Don't repost the same link/image/title within 14 days | `posted_log.json` tracks last-posted date per link; `is_eligible()` blocks reposts inside the cooldown |
| When you do repost, use a new image/title | `variant_index` rotates the title format (declarative → curiosity → outcome) and the overlay hook on every eligible repost |
| Credit the original creator when repurposing video/photo content | Optional `creator_credit` CSV column gets folded into the description |
| FTC/Amazon disclosure on every pin | Appended automatically to every description, can't be accidentally omitted |
| 3-layer Tagged Topics (broad / specific / aesthetic) | `seo.generate_tagged_topic_suggestions()` — see the note below on why these aren't auto-applied |

### A note on Tagged Topics

Pinterest's public API (v5) has no endpoint for setting Tagged Topics — that's
a Pin Creator UI-only feature with a fixed, non-custom vocabulary. The script
still generates the guide's 3-layer suggestions (broad/specific/aesthetic)
and prints them to the workflow log at post time, so you can copy them into
the Pin Creator by hand if you want that extra reach. If Pinterest exposes
this in the API later, it's a small addition to `create_pin()`.

## One-time setup

### 1. Get a Pinterest access token
- Go to [developers.pinterest.com](https://developers.pinterest.com), create
  an app under your Business account.
- Follow Pinterest's OAuth flow to generate an access token with the
  `pins:write` and `boards:read` scopes. (Pinterest's docs walk through this
  step by step — it's a one-time process, not something to re-do per pin.)
- Find your target board's ID (visible via the Pinterest API's boards
  endpoint, or in your board's URL/settings).

### 2. Create a GitHub repo
- Create a free GitHub account if you don't have one.
- Create a new repository and upload all the files in this folder to it.

### 3. Add your secrets
In your repo: **Settings → Secrets and variables → Actions → New repository
secret**. Add:
- `PINTEREST_ACCESS_TOKEN` — the token from step 1
- `DEFAULT_BOARD_ID` — your board ID from step 1 (used if a CSV row doesn't
  specify its own `board_id`)

Never put these directly in the code or CSV — Secrets keep them out of your
repo's visible history.

### 4. Fill in products.csv
Replace the example rows with real products. Columns:

- `product_name`, `amazon_link` (with your tracking tag), `image_url`,
  `board_id`, `price`
- `primary_keyword` — the main search term this product should rank for
  (front-loaded into the title automatically)
- `secondary_keywords` — 1-3 related terms, separated by `;`
- `aesthetic_keywords` — style/vibe terms for the tag suggestions, separated
  by `;` (e.g. `minimalist aesthetic;neutral colors`)
- `who_for`, `problem`, `benefit` — short phrases used to build a natural,
  non-stuffed description
- `creator_credit` — optional; if this pin is built from repurposed
  TikTok/social content, put the creator credit here (e.g.
  `@username on TikTok`) and it's folded into the description automatically
- `category` — free-form, for your own organization

**Important:** `image_url` must be your own hosted photo, a lifestyle shot,
or an edited video frame — not an Amazon product image URL. The script will
refuse to build the pin (and skip that row) if it detects an Amazon image
domain, per the compliance section of the guide.

### 5. Test it manually first
Go to your repo's **Actions** tab → select "Post to Pinterest" → **Run
workflow**. Check that a pin actually appears correctly on your board before
letting the schedule take over.

### 6. Let it run
Once a manual test works, the cron schedule in
`.github/workflows/pinterest-post.yml` takes over automatically — 3 posts/day
by default. Edit the `cron:` lines to change timing or frequency.

## Compliance reminders (don't skip these)

- Every pin's caption includes an affiliate disclosure automatically — this
  is required by the FTC and by Amazon's Associates Operating Agreement.
  Don't remove it.
- Don't cloak or shorten your Amazon links to hide that they're Amazon links
  — this violates Amazon's terms.
- The Amazon-image guard only catches Amazon-hosted URLs — it can't verify
  you have rights to whatever image you *do* host. Use your own photos, or
  video frames you've actually edited/repurposed per the guide's "Repurpose
  Ethically" rules (credit the creator, add your own value, don't just
  re-upload).
- `PINS_PER_RUN` in `generate_and_post.py` defaults to 1. Combined with the
  3x/day cron schedule that's 3 pins/day — in line with the guide's warning
  against jumping straight to 20+/day on a new account. Raise it gradually,
  not all at once.

## When PA-API access clears

Once Amazon approves your Product Advertising API access, you can replace the
manual CSV-editing step with a small script that queries PA-API for trending
products in your niche and writes new rows into `products.csv` automatically.
The posting half (`generate_and_post.py`) doesn't need to change.
