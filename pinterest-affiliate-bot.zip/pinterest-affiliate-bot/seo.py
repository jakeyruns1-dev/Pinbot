"""
Pinterest SEO generation — implements the rules from the affiliate guide:

- Titles front-load the primary keyword in the first 3-4 words, 60-100 chars,
  and come in 3 rotating formats (declarative / curiosity / outcome) so the
  same product doesn't get the same title twice in a row.
- Descriptions put the primary keyword in the first sentence, weave in 2-3
  secondary keywords naturally, cover who-it's-for / problem / benefit, and
  avoid hashtags and bullet-per-emoji stuffing (Pinterest ranks on natural
  keyword phrases, not tag lists, per the guide).
- Alt text is a separate, keyword-rich, descriptive field (the guide calls
  this "the most underused SEO element on Pinterest").
- Tagged Topics: Pinterest's public API (v5) has no endpoint to set Tagged
  Topics — that's a UI-only feature with a fixed, non-custom vocabulary. We
  still generate the 3-layer (broad / specific / aesthetic) suggestions from
  the guide so you can add them manually in the Pin Creator if you want that
  extra reach; the script logs them at post time as a reminder.
"""

import random
import textwrap

DISCLOSURE_TEXT = "As an Amazon Associate I earn from qualifying purchases."

TITLE_TEMPLATES = {
    # {kw} = primary keyword, front-loaded within the first few words.
    "declarative": "{kw_title}: {benefit}",
    "curiosity": "This {kw_title} Is Why Everyone's Talking About It",
    "outcome": "{kw_title} That Actually {benefit_verb}",
}

# Curiosity-gap overlay hooks for the pin IMAGE — per the guide's
# troubleshooting section, showing too much kills clicks. These hint at the
# benefit without fully explaining it, and rotate per post for freshness.
OVERLAY_HOOK_TEMPLATES = [
    "The {kw} everyone's saving for later",
    "Why this {kw} keeps selling out",
    "This {kw} hack changes everything",
    "The {kw} nobody told you about",
    "POV: you finally found the right {kw}",
]

CTA_TEXTS = [
    "Tap to see why 👇",
    "Shop this find below",
    "Check the price on Amazon",
    "See why it went viral",
]


def _title_case_keyword(kw: str) -> str:
    return " ".join(w.capitalize() for w in kw.split())


def generate_title(primary_keyword, benefit, variant_index=0):
    """Rotate through the 3 formats so reposts of the same product don't
    reuse the same title (freshness rule)."""
    formats = list(TITLE_TEMPLATES.keys())
    fmt = formats[variant_index % len(formats)]
    kw_title = _title_case_keyword(primary_keyword)
    benefit_verb = benefit if benefit else "Works"
    title = TITLE_TEMPLATES[fmt].format(
        kw_title=kw_title, benefit=benefit or "See Why It's Trending", benefit_verb=benefit_verb
    )
    # Keep within Pinterest's practical title window (60-100 chars is the
    # guide's target; hard-cap at 100 so nothing gets silently truncated).
    if len(title) > 100:
        title = title[:97].rstrip() + "..."
    return title


def generate_description(primary_keyword, secondary_keywords, who_for, problem, benefit,
                          creator_credit=None):
    """Primary keyword in sentence 1, secondary keywords woven naturally
    into 2-3 short sentences, no bullets, no hashtags, no keyword-stuffing
    list — matches the guide's 'Strategic SEO' example exactly."""
    secondary = [k.strip() for k in secondary_keywords if k.strip()]
    sec_phrase = ""
    if secondary:
        if len(secondary) == 1:
            sec_phrase = secondary[0]
        else:
            sec_phrase = f"{secondary[0]} and {secondary[1]}"

    sentence1 = f"If you're looking for {primary_keyword}, this is worth a look."
    parts = [sentence1]

    body = []
    if who_for:
        body.append(f"Great for {who_for.lower()}")
    if problem:
        body.append(f"solves {problem.lower()}" if who_for else f"Solves {problem.lower()}")
    body_sentence = ", ".join(body) if body else ""
    if body_sentence:
        parts.append(body_sentence.strip().capitalize() + ".")

    if benefit or sec_phrase:
        bits = []
        if benefit:
            bits.append(benefit)
        if sec_phrase:
            bits.append(f"one of the better options if you're comparing {sec_phrase}")
        parts.append(" — ".join(bits).strip().capitalize() + ".")

    if creator_credit:
        parts.append(f"Video credit: {creator_credit}.")

    parts.append(DISCLOSURE_TEXT)

    description = " ".join(parts)
    if len(description) > 500:
        description = description[:497].rstrip() + "..."
    return description


def generate_alt_text(product_name, primary_keyword):
    return f"{product_name} — {primary_keyword}"[:500]


def generate_tagged_topic_suggestions(primary_keyword, secondary_keywords, aesthetic_keywords):
    """3-layer tag strategy from the guide. Not settable via the public API
    (see module docstring) — returned so the script can log/print them for
    manual entry, and so a future UI-automation layer has them ready."""
    broad = [primary_keyword, "Amazon Finds"]
    specific = [primary_keyword] + [k.strip() for k in secondary_keywords if k.strip()]
    aesthetic = [k.strip() for k in aesthetic_keywords if k.strip()]
    tags = []
    for group in (broad, specific, aesthetic):
        for t in group:
            if t and t not in tags:
                tags.append(t)
    return tags[:10]


def pick_overlay_hook(primary_keyword, variant_index=0):
    template = OVERLAY_HOOK_TEMPLATES[variant_index % len(OVERLAY_HOOK_TEMPLATES)]
    hook = template.format(kw=primary_keyword)
    return textwrap.fill(hook, width=22)


def pick_cta(variant_index=0):
    return CTA_TEXTS[variant_index % len(CTA_TEXTS)]
