"""
Pinterest Affiliate Auto-Poster (v2 — SEO + freshness optimized)
------------------------------------------------------------------
Rebuilt around the affiliate guide's rules:

  - Pin SEO: front-loaded primary keyword in the title, natural (not
    stuffed) keyword-rich description, dedicated alt text, 3-layer tag
    suggestions logged for manual entry (see seo.py docstring re: API
    limits).
  - Image: curiosity-gap overlay text instead of a full reveal, a direct
    CTA strip, high-contrast mobile-safe text, and a hard refusal to use
    an Amazon-hosted image as the pin image.
  - Anti-spam / freshness: the same amazon_link will not be reposted
    within 14 days, and when it IS reposted, the script automatically
    rotates to a different title format and overlay hook so it's never
    the exact same title/image/description twice (per the guide's
    "Anti-Spam Strategy" section).
  - Compliance: every description ends with the FTC/Amazon disclosure
    automatically. If a creator_credit is given (for repurposed video
    content), it's included in the description too.

Required environment variables (GitHub Secrets):
  PINTEREST_ACCESS_TOKEN   - OAuth access token for your Pinterest app
  DEFAULT_BOARD_ID         - fallback board_id if a CSV row doesn't specify one

Required files:
  products.csv     - see the header row for all fields (documented in README.md)
  posted_log.json  - created/updated automatically; tracks last-posted date
                      and which title/overlay variant was used per product
"""

import csv
import os
import sys
import json
import base64
from datetime import datetime, timezone, timedelta

import requests

import seo
import image_gen

PINS_PER_RUN = 1
CSV_PATH = "products.csv"
LOG_PATH = "posted_log.json"
PINTEREST_API_BASE = "https://api.pinterest.com/v5"
REPOST_COOLDOWN_DAYS = 14  # matches the guide's "space Pins out by at least 14 days" rule


def load_posted_log():
    if not os.path.exists(LOG_PATH):
        return {}
    with open(LOG_PATH, "r") as f:
        try:
            return json.load(f)
        except json.JSONDecodeError:
            return {}


def save_posted_log(log):
    with open(LOG_PATH, "w") as f:
        json.dump(log, f, indent=2)


def is_eligible(amazon_link, log):
    """True if never posted, or last posted more than REPOST_COOLDOWN_DAYS ago."""
    entry = log.get(amazon_link)
    if not entry:
        return True
    last_posted = datetime.fromisoformat(entry["last_posted"])
    return datetime.now(timezone.utc) - last_posted > timedelta(days=REPOST_COOLDOWN_DAYS)


def next_variant_index(amazon_link, log):
    entry = log.get(amazon_link)
    if not entry:
        return 0
    return entry.get("variant_index", 0) + 1


def load_candidate_products():
    log = load_posted_log()
    candidates = []
    with open(CSV_PATH, newline="", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        for row in reader:
            link = row.get("amazon_link", "").strip()
            if link and is_eligible(link, log):
                candidates.append(row)
    return candidates, log


def split_keywords(raw):
    return [k.strip() for k in raw.split(";") if k.strip()] if raw else []


def create_pin(image_bytes, title, description, alt_text, amazon_link, board_id, access_token):
    b64_image = base64.b64encode(image_bytes).decode("utf-8")
    payload = {
        "board_id": board_id,
        "title": title[:100],
        "alt_text": alt_text[:500],
        "description": description[:800],
        "link": amazon_link,
        "media_source": {
            "source_type": "image_base64",
            "content_type": "image/jpeg",
            "data": b64_image,
        },
    }
    resp = requests.post(
        f"{PINTEREST_API_BASE}/pins",
        headers={
            "Authorization": f"Bearer {access_token}",
            "Content-Type": "application/json",
        },
        json=payload,
        timeout=30,
    )
    resp.raise_for_status()
    return resp.json()


def process_row(row, variant_index, access_token, default_board_id):
    product_name = row["product_name"].strip()
    amazon_link = row["amazon_link"].strip()
    image_url = row["image_url"].strip()
    board_id = row.get("board_id", "").strip() or default_board_id
    price = row.get("price", "").strip()

    primary_keyword = row.get("primary_keyword", "").strip() or product_name
    secondary_keywords = split_keywords(row.get("secondary_keywords", ""))
    aesthetic_keywords = split_keywords(row.get("aesthetic_keywords", ""))
    who_for = row.get("who_for", "").strip()
    problem = row.get("problem", "").strip()
    benefit = row.get("benefit", "").strip()
    creator_credit = row.get("creator_credit", "").strip() or None

    if not board_id:
        raise ValueError(f"No board_id set for '{product_name}' (row or DEFAULT_BOARD_ID).")

    title = seo.generate_title(primary_keyword, benefit, variant_index)
    description = seo.generate_description(
        primary_keyword, secondary_keywords, who_for, problem, benefit, creator_credit
    )
    alt_text = seo.generate_alt_text(product_name, primary_keyword)
    tag_suggestions = seo.generate_tagged_topic_suggestions(
        primary_keyword, secondary_keywords, aesthetic_keywords
    )

    overlay_hook = seo.pick_overlay_hook(primary_keyword, variant_index)
    cta_text = seo.pick_cta(variant_index)
    image_bytes = image_gen.build_pin_image(image_url, overlay_hook, cta_text, price)

    print(f"  Title      : {title}")
    print(f"  Description: {description}")
    print(f"  Alt text   : {alt_text}")
    print(f"  Suggested Tagged Topics (add manually in Pin Creator): {', '.join(tag_suggestions)}")

    result = create_pin(image_bytes, title, description, alt_text, amazon_link, board_id, access_token)
    return result


def main():
    access_token = os.environ.get("PINTEREST_ACCESS_TOKEN")
    default_board_id = os.environ.get("DEFAULT_BOARD_ID", "")

    if not access_token:
        print("ERROR: PINTEREST_ACCESS_TOKEN environment variable is not set.")
        sys.exit(1)

    candidates, log = load_candidate_products()
    if not candidates:
        print("No eligible products right now (everything is either posted or within "
              f"the {REPOST_COOLDOWN_DAYS}-day cooldown). Add more rows to products.csv.")
        return

    batch = candidates[:PINS_PER_RUN]

    for row in batch:
        product_name = row["product_name"].strip()
        amazon_link = row["amazon_link"].strip()
        variant_index = next_variant_index(amazon_link, log)

        print(f"[{datetime.now(timezone.utc).isoformat()}] Building pin: {product_name} "
              f"(variant {variant_index})")

        try:
            result = process_row(row, variant_index, access_token, default_board_id)
            print(f"  Posted pin id: {result.get('id')}")
            log[amazon_link] = {
                "last_posted": datetime.now(timezone.utc).isoformat(),
                "variant_index": variant_index,
                "product_name": product_name,
            }
            save_posted_log(log)
        except image_gen.AmazonImageError as e:
            print(f"  SKIPPED '{product_name}': {e}")
        except requests.HTTPError as e:
            print(f"  FAILED to post '{product_name}': {e.response.status_code} {e.response.text}")
        except Exception as e:
            print(f"  FAILED to post '{product_name}': {e}")


if __name__ == "__main__":
    main()
