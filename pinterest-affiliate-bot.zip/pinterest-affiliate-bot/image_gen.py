"""
Pin image generation — implements the guide's image rules:

- Vertical 2:3 canvas (Pinterest's preferred ratio).
- Bold, high-contrast, large text that reads "at arm's length" on mobile.
- Overlay text is a curiosity hook, not a full reveal (the guide's #1 fix
  for high-impressions/low-clicks pins).
- A short CTA near the bottom ("Shop this find below", not "link in bio").
- NEVER use an Amazon-hosted product image as the pin image — the guide
  flags this as a copyright/ban risk. This module refuses to build a pin
  from an amazon.com / media-amazon.com image URL.
"""

import io
import textwrap
import requests
from PIL import Image, ImageDraw, ImageFont

AMAZON_IMAGE_DOMAINS = ("media-amazon.com", "images-amazon.com", "ssl-images-amazon.com")

TARGET_W, TARGET_H = 1000, 1500
BANNER_H = 260
CTA_H = 70


class AmazonImageError(ValueError):
    """Raised when the source image_url is hosted on an Amazon domain."""


def assert_not_amazon_image(image_url: str):
    lowered = image_url.lower()
    if any(domain in lowered for domain in AMAZON_IMAGE_DOMAINS):
        raise AmazonImageError(
            f"Refusing to use an Amazon-hosted image ({image_url}). "
            "Use your own product photo, a lifestyle shot, or a repurposed/edited "
            "video frame instead — Amazon product images can get your Pinterest "
            "account flagged, per the compliance guide."
        )


def _load_font(size, bold=True):
    path = "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf" if bold \
        else "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"
    try:
        return ImageFont.truetype(path, size)
    except OSError:
        return ImageFont.load_default()


def build_pin_image(image_url, overlay_hook, cta_text, price=""):
    """Returns JPEG bytes for a Pinterest-ready 2:3 pin image."""
    assert_not_amazon_image(image_url)

    resp = requests.get(image_url, timeout=20)
    resp.raise_for_status()
    photo = Image.open(io.BytesIO(resp.content)).convert("RGB")

    photo_area_h = TARGET_H - BANNER_H - CTA_H - 40
    photo.thumbnail((TARGET_W - 80, photo_area_h))
    canvas = Image.new("RGB", (TARGET_W, TARGET_H), "white")
    offset_x = (TARGET_W - photo.width) // 2
    offset_y = 40 + (photo_area_h - photo.height) // 2
    canvas.paste(photo, (offset_x, offset_y))

    draw = ImageDraw.Draw(canvas)
    hook_font = _load_font(56)
    cta_font = _load_font(34)
    price_font = _load_font(38)

    # Curiosity-hook banner (bottom, high contrast)
    banner_top = TARGET_H - BANNER_H - CTA_H
    draw.rectangle([(0, banner_top), (TARGET_W, banner_top + BANNER_H)], fill=(18, 18, 18))
    wrapped_hook = textwrap.fill(overlay_hook, width=20)
    draw.multiline_text(
        (40, banner_top + 30), wrapped_hook, font=hook_font, fill="white", spacing=12
    )

    # CTA strip (very bottom, accent color, short and direct)
    cta_top = TARGET_H - CTA_H
    draw.rectangle([(0, cta_top), (TARGET_W, TARGET_H)], fill=(230, 57, 70))
    draw.text((40, cta_top + 16), cta_text, font=cta_font, fill="white")

    # Price badge (top-left, only if provided)
    if price:
        draw.rectangle([(0, 0), (240, 90)], fill=(20, 20, 20))
        draw.text((28, 22), price, font=price_font, fill="white")

    out = io.BytesIO()
    canvas.save(out, format="JPEG", quality=90)
    return out.getvalue()
